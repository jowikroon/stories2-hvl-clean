CCP Crawler Runner — Chrome Extension (MV3)

Deze extensie praat met een lokale runner op:
  http://127.0.0.1:8787

Token (moet matchen met jouw server.py API_TOKEN):
  o2Xx4krari1tJ79DF0hh4E321b4FFEdKtgxE8DLntUc

Installeren:
1) Pak deze ZIP uit naar een map.
2) Chrome → chrome://extensions → Developer mode ON
3) Load unpacked → selecteer de uitgepakte map.

Let op: je moet ook een lokale server draaien die de endpoints /start /status /stop aanbiedt.
