const BASE = "http://127.0.0.1:8787";
const TOKEN = "o2Xx4krari1tJ79DF0hh4E321b4FFEdKtgxE8DLntUc";

const el = (id) => document.getElementById(id);

async function api(path, method = "GET", body = null) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      "X-Runner-Token": TOKEN
    },
    body: body ? JSON.stringify(body) : null
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`HTTP ${res.status}: ${txt}`);
  }
  return res.json();
}

function setState(text) {
  el("state").textContent = `State: ${text}`;
}

function setLog(text) {
  el("log").textContent = text || "";
}

async function doStatus() {
  setState("status ophalen...");
  try {
    const data = await api("/status");
    setState(data.running ? "RUNNING" : "NOT RUNNING");
    setLog(data.log_tail || data.bat_output || "");
  } catch (e) {
    setState("ERROR");
    setLog(String(e));
  }
}

async function doStart() {
  const url = el("url").value.trim();
  const label = el("label").value.trim();
  const sample = parseInt(el("sample").value.trim() || "200", 10);
  const autoDoor = el("autoDoor").value === "true";

  if (!url || !label) {
    setState("ERROR");
    setLog("Vul URL en Label in.");
    return;
  }

  setState("starten...");
  try {
    const data = await api("/start", "POST", { url, label, sample, auto_door: autoDoor });
    setState(data.ok ? "STARTED" : "FAILED");
    setLog(data.output || "");
    await doStatus();
  } catch (e) {
    setState("ERROR");
    setLog(String(e));
  }
}

async function doStop() {
  setState("stoppen...");
  try {
    const data = await api("/stop", "POST", {});
    setState(data.ok ? "STOPPED" : "FAILED");
    setLog(data.output || "");
    await doStatus();
  } catch (e) {
    setState("ERROR");
    setLog(String(e));
  }
}

el("startBtn").addEventListener("click", doStart);
el("statusBtn").addEventListener("click", doStatus);
el("stopBtn").addEventListener("click", doStop);

doStatus();
