# Testing Guide - Product Page Analyzer

## Test Product Pages

Here are recommended product pages to test the extension:

### E-commerce Platforms

#### Amazon
- **URL**: https://www.amazon.com/s?k=laptop
- **Expected**: High scores (good product pages)
- **Test**: Click on any product

#### Shopify Stores
- **URL**: https://www.shopify.com/blog/ecommerce-examples
- **Expected**: Variable scores
- **Test**: Visit store examples

#### WooCommerce
- **URL**: https://www.woothemes.com/products/
- **Expected**: Medium to high scores
- **Test**: Click products

### Test Scenarios

#### Scenario 1: Well-Optimized Page
1. Go to Amazon
2. Search for a popular product
3. Click on a product with many reviews
4. Analyze the page
5. **Expected Result**: Score 70-90+

#### Scenario 2: Minimal Product Page
1. Find a small e-commerce site
2. Look for a basic product page
3. Analyze the page
4. **Expected Result**: Score 30-60

#### Scenario 3: Non-Product Page
1. Go to a blog post or article
2. Try to analyze
3. **Expected Result**: Low score, many missing elements

## Feature Testing Checklist

### Popup Functionality
- [ ] Extension icon appears in toolbar
- [ ] Clicking icon opens popup
- [ ] Popup displays correctly
- [ ] "Analyze Product Page" button is clickable
- [ ] Loading spinner appears during analysis
- [ ] "View Full Report" button appears after analysis

### Analysis Functionality
- [ ] Page scanning completes without errors
- [ ] Analysis takes 2-5 seconds
- [ ] Results are stored in chrome.storage
- [ ] Multiple analyses can be performed
- [ ] Different pages show different scores

### Report Display
- [ ] Report page loads correctly
- [ ] Overall score displays prominently
- [ ] Page information shows correctly
- [ ] Category breakdown displays
- [ ] All 20 elements are listed
- [ ] Tab filtering works (All, Present, Partial, Missing)
- [ ] Recommendations display with priorities

### UI/UX Testing
- [ ] Momentum-inspired design is visible
- [ ] Colors are consistent (purple gradient)
- [ ] Typography is readable
- [ ] Buttons are clickable
- [ ] Responsive on different screen sizes
- [ ] No layout issues

### Export Functionality
- [ ] Download button works
- [ ] File downloads with correct name
- [ ] File contains all analysis data
- [ ] Share button works
- [ ] Share text is formatted correctly

## Browser Compatibility Testing

### Chrome
- [ ] Version 90+
- [ ] Works with latest version
- [ ] No console errors

### Edge
- [ ] Loads extension
- [ ] Analysis works
- [ ] Report displays

### Brave
- [ ] Loads extension
- [ ] Analysis works
- [ ] Report displays

## Performance Testing

### Load Time
- [ ] Popup opens in < 500ms
- [ ] Analysis completes in < 5 seconds
- [ ] Report page loads in < 2 seconds

### Memory Usage
- [ ] Extension uses < 50MB RAM
- [ ] No memory leaks after multiple analyses
- [ ] Storage doesn't grow excessively

### Accuracy Testing

### Element Detection
- [ ] Featured images detected correctly
- [ ] Product ratings identified
- [ ] CTAs found and analyzed
- [ ] Pricing information detected
- [ ] Shipping info identified
- [ ] Reviews/testimonials found
- [ ] Payment options detected

### Scoring Accuracy
- [ ] Well-optimized pages score high (70+)
- [ ] Poor pages score low (< 50)
- [ ] Scores are consistent on re-analysis
- [ ] Different pages show different scores

## Edge Case Testing

### Test Case 1: Single Product Image
- **Page**: Product with only 1 image
- **Expected**: Image Gallery marked as "Missing"
- **Result**: ✓ / ✗

### Test Case 2: No Reviews
- **Page**: New product with no reviews
- **Expected**: Ratings marked as "Missing"
- **Result**: ✓ / ✗

### Test Case 3: Slow Loading Page
- **Page**: Page that loads in > 5 seconds
- **Expected**: Page Speed marked as "Missing"
- **Result**: ✓ / ✗

### Test Case 4: Unusual HTML Structure
- **Page**: Custom-built site with non-standard HTML
- **Expected**: Some elements may show "Unknown"
- **Result**: ✓ / ✗

### Test Case 5: Mobile Product Page
- **Page**: Mobile version of e-commerce site
- **Expected**: Analysis still works
- **Result**: ✓ / ✗

## Regression Testing

### After Each Update
1. [ ] Analyze a well-known product page
2. [ ] Verify score hasn't changed significantly
3. [ ] Check all UI elements display
4. [ ] Test export functionality
5. [ ] Verify no new errors in console

## User Acceptance Testing

### Task 1: First Time User
1. [ ] User can install extension
2. [ ] User can find extension in toolbar
3. [ ] User can analyze a product page
4. [ ] User understands the report

### Task 2: Power User
1. [ ] User can analyze multiple pages
2. [ ] User can export reports
3. [ ] User can share results
4. [ ] User can understand recommendations

### Task 3: Troubleshooting
1. [ ] User can fix common issues
2. [ ] User can find help documentation
3. [ ] User can contact support

## Test Results Template

```
Test Date: _______________
Tester: ___________________
Browser: __________________
OS: _______________________

Test Case: ________________
Expected Result: __________
Actual Result: ____________
Status: ✓ PASS / ✗ FAIL

Notes: _____________________
_____________________________
```

## Known Issues & Workarounds

### Issue 1: Analysis Takes Too Long
- **Cause**: Complex page structure
- **Workaround**: Try a different product page

### Issue 2: Low Confidence Scores
- **Cause**: Non-standard HTML
- **Workaround**: Manual review recommended

### Issue 3: Report Not Showing
- **Cause**: Storage cleared
- **Workaround**: Re-analyze the page

## Performance Benchmarks

| Metric | Target | Actual |
|--------|--------|--------|
| Popup Load | < 500ms | ___ |
| Analysis Time | < 5s | ___ |
| Report Load | < 2s | ___ |
| Memory Usage | < 50MB | ___ |
| Storage Size | < 10MB | ___ |

## Automated Testing

### Future: Unit Tests
```javascript
// Example test structure
describe('Content Script', () => {
  test('should detect featured images', () => {
    // Test implementation
  });
  
  test('should calculate score correctly', () => {
    // Test implementation
  });
});
```

### Future: Integration Tests
- Test popup → content script communication
- Test content script → background script communication
- Test storage functionality

## Continuous Testing

### Weekly
- [ ] Test on latest Chrome version
- [ ] Analyze 5 different product pages
- [ ] Check for console errors

### Monthly
- [ ] Full regression test
- [ ] Performance benchmarking
- [ ] User feedback review

### Before Release
- [ ] All test cases pass
- [ ] No console errors
- [ ] Performance meets benchmarks
- [ ] Documentation updated

---

**Testing Status**: Ready for QA

For issues found during testing, please document:
1. Steps to reproduce
2. Expected vs actual result
3. Browser and OS
4. Screenshots if applicable
