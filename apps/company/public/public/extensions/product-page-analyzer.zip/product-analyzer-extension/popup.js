// State Management
const PopupState = {
  READY: 'ready',
  LOADING: 'loading',
  RESULTS: 'results',
  ERROR: 'error'
};

let currentState = PopupState.READY;
let analysisHistory = [];
let currentAnalysis = null;

// DOM Elements
const readyState = document.getElementById('readyState');
const loadingState = document.getElementById('loadingState');
const resultsState = document.getElementById('resultsState');
const errorState = document.getElementById('errorState');

const analyzeBtn = document.getElementById('analyzeBtn');
const viewReportBtn = document.getElementById('viewReportBtn');
const compareBtn = document.getElementById('compareBtn');
const analyzeAgainBtn = document.getElementById('analyzeAgainBtn');
const retryBtn = document.getElementById('retryBtn');
const settingsBtn = document.getElementById('settingsBtn');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  analyzeBtn.addEventListener('click', startAnalysis);
  viewReportBtn.addEventListener('click', viewReport);
  compareBtn.addEventListener('click', openComparison);
  analyzeAgainBtn.addEventListener('click', resetToReady);
  retryBtn.addEventListener('click', startAnalysis);
  settingsBtn.addEventListener('click', openSettings);

  // Load previous analysis if exists
  loadPreviousAnalysis();
});

/**
 * Load previous analysis from storage
 */
function loadPreviousAnalysis() {
  chrome.storage.local.get(['analysisHistory', 'currentAnalysis'], (result) => {
    if (result.analysisHistory) {
      analysisHistory = result.analysisHistory;
    }
    if (result.currentAnalysis) {
      currentAnalysis = result.currentAnalysis;
      displayResults(currentAnalysis);
      setState(PopupState.RESULTS);
    }
  });
}

/**
 * Start analysis of current page
 */
function startAnalysis() {
  setState(PopupState.LOADING);
  
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    
    // Send message to content script to analyze the page
    chrome.tabs.sendMessage(currentTab.id, { action: 'analyze' }, (response) => {
      if (chrome.runtime.lastError) {
        showError('Unable to analyze this page. Please try again.');
        return;
      }

      if (response && response.success) {
        currentAnalysis = {
          ...response.analysis,
          url: currentTab.url,
          title: currentTab.title,
          timestamp: new Date().toISOString()
        };

        // Save to history
        analysisHistory.unshift(currentAnalysis);
        if (analysisHistory.length > 10) {
          analysisHistory = analysisHistory.slice(0, 10);
        }

        // Save to storage
        chrome.storage.local.set({
          currentAnalysis: currentAnalysis,
          analysisHistory: analysisHistory
        });

        displayResults(currentAnalysis);
        setState(PopupState.RESULTS);
      } else {
        showError(response?.error || 'Analysis failed. Please try again.');
      }
    });
  });
}

/**
 * Display analysis results
 */
function displayResults(analysis) {
  const scoreNumber = document.getElementById('scoreNumber');
  const scoreTitle = document.getElementById('scoreTitle');
  const scoreDescription = document.getElementById('scoreDescription');
  const presentCount = document.getElementById('presentCount');
  const partialCount = document.getElementById('partialCount');
  const missingCount = document.getElementById('missingCount');

  const score = Math.round(analysis.score || 0);
  
  // Animate score
  animateScore(scoreNumber, score);
  
  // Set title and description based on score
  const { title, description } = getScoreInterpretation(score);
  scoreTitle.textContent = title;
  scoreDescription.textContent = description;

  // Update stats
  const present = analysis.results.filter(r => r.status === 'present').length;
  const partial = analysis.results.filter(r => r.status === 'partial').length;
  const missing = analysis.results.filter(r => r.status === 'missing').length;

  presentCount.textContent = present;
  partialCount.textContent = partial;
  missingCount.textContent = missing;

  // Update progress ring
  updateProgressRing(score);

  // Enable/disable compare button based on history
  compareBtn.disabled = analysisHistory.length < 2;
  if (analysisHistory.length < 2) {
    compareBtn.style.opacity = '0.5';
    compareBtn.style.cursor = 'not-allowed';
  }
}

/**
 * Animate score counter
 */
function animateScore(element, targetScore) {
  let currentScore = 0;
  const increment = targetScore / 30;
  const interval = setInterval(() => {
    currentScore += increment;
    if (currentScore >= targetScore) {
      currentScore = targetScore;
      clearInterval(interval);
    }
    element.textContent = Math.round(currentScore);
  }, 30);
}

/**
 * Update SVG progress ring
 */
function updateProgressRing(score) {
  const circle = document.querySelector('.score-ring-progress');
  if (circle) {
    const circumference = 2 * Math.PI * 54;
    const offset = circumference - (score / 100) * circumference;
    circle.style.strokeDashoffset = offset;
  }
}

/**
 * Get score interpretation
 */
function getScoreInterpretation(score) {
  if (score >= 80) {
    return {
      title: 'Excellent',
      description: 'Your page is well optimized for conversions'
    };
  } else if (score >= 60) {
    return {
      title: 'Good',
      description: 'Your page has solid optimization, but room for improvement'
    };
  } else if (score >= 40) {
    return {
      title: 'Fair',
      description: 'Several optimization opportunities available'
    };
  } else {
    return {
      title: 'Needs Work',
      description: 'Significant improvements recommended'
    };
  }
}

/**
 * View full report
 */
function viewReport() {
  if (currentAnalysis) {
    // Save current analysis to storage
    chrome.storage.local.set({ currentAnalysis: currentAnalysis }, () => {
      chrome.tabs.create({ url: 'report.html' });
    });
  }
}

/**
 * Open comparison tool
 */
function openComparison() {
  if (analysisHistory.length < 2) {
    showError('Need at least 2 analyses to compare. Analyze another page first.');
    return;
  }

  // Save history to storage
  chrome.storage.local.set({ analysisHistory: analysisHistory }, () => {
    chrome.tabs.create({ url: 'report.html?mode=compare' });
  });
}

/**
 * Open settings
 */
function openSettings() {
  chrome.tabs.create({ url: 'report.html?mode=settings' });
}

/**
 * Show error state
 */
function showError(message) {
  const errorMessage = document.getElementById('errorMessage');
  errorMessage.textContent = message;
  setState(PopupState.ERROR);
}

/**
 * Reset to ready state
 */
function resetToReady() {
  setState(PopupState.READY);
}

/**
 * Set popup state
 */
function setState(newState) {
  // Hide all states
  readyState.classList.remove('active');
  loadingState.classList.remove('active');
  resultsState.classList.remove('active');
  errorState.classList.remove('active');

  // Show new state
  switch (newState) {
    case PopupState.READY:
      readyState.classList.add('active');
      break;
    case PopupState.LOADING:
      loadingState.classList.add('active');
      break;
    case PopupState.RESULTS:
      resultsState.classList.add('active');
      break;
    case PopupState.ERROR:
      errorState.classList.add('active');
      break;
  }

  currentState = newState;
}

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'analysisComplete') {
    currentAnalysis = request.analysis;
    displayResults(currentAnalysis);
    setState(PopupState.RESULTS);
  }
});
