// Background Service Worker

chrome.runtime.onInstalled.addListener(() => {
    console.log('Product Page Analyzer extension installed');
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'analysisComplete') {
        // Store analysis in chrome storage
        chrome.storage.local.set({
            lastAnalysis: request.data,
            lastAnalysisTime: new Date().toISOString()
        });
    }
});
