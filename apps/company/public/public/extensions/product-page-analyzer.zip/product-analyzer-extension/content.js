// Product Page Analyzer - Content Script

const CONVERSION_CRITERIA = {
    featuredImage: {
        name: 'Featured Image Quality',
        category: 'Visual & Content',
        weight: 8,
        check: () => {
            const images = document.querySelectorAll('img[alt*="product"], img[alt*="Product"], img[src*="product"]');
            if (images.length === 0) return { status: 'missing', confidence: 0.9 };
            
            let largeImages = 0;
            images.forEach(img => {
                if (img.naturalWidth >= 500 && img.naturalHeight >= 500) {
                    largeImages++;
                }
            });
            
            if (largeImages > 0) return { status: 'present', confidence: 0.85 };
            return { status: 'partial', confidence: 0.6 };
        }
    },
    
    imageGallery: {
        name: 'Image Gallery (Multiple Angles)',
        category: 'Visual & Content',
        weight: 8,
        check: () => {
            const gallery = document.querySelector('[class*="gallery"], [class*="carousel"], [class*="slider"]');
            const productImages = document.querySelectorAll('img[alt*="product"], img[alt*="Product"]');
            
            if (gallery && productImages.length >= 3) return { status: 'present', confidence: 0.9 };
            if (productImages.length >= 3) return { status: 'present', confidence: 0.75 };
            if (productImages.length >= 2) return { status: 'partial', confidence: 0.6 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    productTitle: {
        name: 'Descriptive Product Title',
        category: 'Visual & Content',
        weight: 7,
        check: () => {
            const h1 = document.querySelector('h1');
            const title = document.querySelector('[class*="title"]');
            const productName = h1 || title;
            
            if (!productName) return { status: 'missing', confidence: 0.8 };
            
            const text = productName.textContent.trim();
            if (text.length > 30 && text.length < 200) {
                return { status: 'present', confidence: 0.85 };
            }
            if (text.length > 10) return { status: 'partial', confidence: 0.65 };
            return { status: 'missing', confidence: 0.7 };
        }
    },
    
    productRatings: {
        name: 'Product Ratings (First Fold)',
        category: 'Trust & Social Proof',
        weight: 9,
        check: () => {
            const ratings = document.querySelector('[class*="rating"], [class*="stars"], [class*="review"]');
            const ratingText = document.body.textContent;
            
            if (ratings) return { status: 'present', confidence: 0.9 };
            if (ratingText.includes('★') || ratingText.includes('⭐')) {
                return { status: 'present', confidence: 0.8 };
            }
            if (ratingText.match(/\d+\s*out of\s*5|(\d+\.\d+)\s*\/\s*5/i)) {
                return { status: 'present', confidence: 0.75 };
            }
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    customerReviews: {
        name: 'Customer Reviews & Testimonials',
        category: 'Trust & Social Proof',
        weight: 8,
        check: () => {
            const reviews = document.querySelectorAll('[class*="review"], [class*="testimonial"], [class*="comment"]');
            const reviewText = document.body.textContent;
            
            if (reviews.length >= 3) return { status: 'present', confidence: 0.9 };
            if (reviewText.match(/customer\s+review|verified\s+purchase|customer\s+said/i)) {
                return { status: 'present', confidence: 0.8 };
            }
            if (reviews.length > 0) return { status: 'partial', confidence: 0.7 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    returnPolicy: {
        name: 'Return Policy Highlighted',
        category: 'Trust & Social Proof',
        weight: 7,
        check: () => {
            const pageText = document.body.textContent.toLowerCase();
            if (pageText.includes('return') && pageText.includes('policy')) {
                return { status: 'present', confidence: 0.85 };
            }
            if (pageText.includes('return') || pageText.includes('refund')) {
                return { status: 'partial', confidence: 0.7 };
            }
            return { status: 'missing', confidence: 0.9 };
        }
    },
    
    paymentOptions: {
        name: 'Multiple Payment Options',
        category: 'Trust & Social Proof',
        weight: 7,
        check: () => {
            const pageText = document.body.textContent.toLowerCase();
            const paymentMethods = ['credit card', 'debit', 'paypal', 'apple pay', 'google pay', 'stripe', 'klarna'];
            const found = paymentMethods.filter(method => pageText.includes(method)).length;
            
            if (found >= 3) return { status: 'present', confidence: 0.9 };
            if (found >= 2) return { status: 'partial', confidence: 0.75 };
            if (found >= 1) return { status: 'partial', confidence: 0.6 };
            return { status: 'missing', confidence: 0.8 };
        }
    },
    
    prominentCTA: {
        name: 'Prominent CTA Button',
        category: 'Conversion Optimization',
        weight: 10,
        check: () => {
            const buttons = document.querySelectorAll('button, a[role="button"]');
            let ctaFound = false;
            let isProminent = false;
            
            buttons.forEach(btn => {
                const text = btn.textContent.toLowerCase();
                if (text.includes('add to cart') || text.includes('buy now') || text.includes('purchase')) {
                    ctaFound = true;
                    
                    const style = window.getComputedStyle(btn);
                    const bgColor = style.backgroundColor;
                    const fontSize = parseInt(style.fontSize);
                    
                    if (fontSize >= 14) isProminent = true;
                }
            });
            
            if (ctaFound && isProminent) return { status: 'present', confidence: 0.9 };
            if (ctaFound) return { status: 'partial', confidence: 0.75 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    priceDisplay: {
        name: 'Clear Price Display with Anchoring',
        category: 'Conversion Optimization',
        weight: 9,
        check: () => {
            const priceElements = document.querySelectorAll('[class*="price"], [class*="cost"]');
            const pageText = document.body.textContent;
            
            if (priceElements.length > 0) {
                const hasDiscount = pageText.match(/\$\d+\s*-\s*\$\d+|save|discount|off|original/i);
                if (hasDiscount) return { status: 'present', confidence: 0.9 };
                return { status: 'partial', confidence: 0.8 };
            }
            if (pageText.match(/\$\d+/)) return { status: 'partial', confidence: 0.7 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    incentives: {
        name: 'Incentives & Savings Display',
        category: 'Conversion Optimization',
        weight: 7,
        check: () => {
            const pageText = document.body.textContent.toLowerCase();
            const incentiveKeywords = ['discount', 'free', 'save', 'limited', 'offer', 'deal', 'promotion'];
            const found = incentiveKeywords.filter(kw => pageText.includes(kw)).length;
            
            if (found >= 3) return { status: 'present', confidence: 0.85 };
            if (found >= 2) return { status: 'partial', confidence: 0.7 };
            if (found >= 1) return { status: 'partial', confidence: 0.6 };
            return { status: 'missing', confidence: 0.8 };
        }
    },
    
    breadcrumbs: {
        name: 'Breadcrumb Navigation',
        category: 'Information Architecture',
        weight: 5,
        check: () => {
            const breadcrumb = document.querySelector('[class*="breadcrumb"], nav[aria-label*="breadcrumb"]');
            if (breadcrumb) return { status: 'present', confidence: 0.9 };
            return { status: 'missing', confidence: 0.8 };
        }
    },
    
    faqSection: {
        name: 'FAQ Section Access',
        category: 'Information Architecture',
        weight: 6,
        check: () => {
            const pageText = document.body.textContent.toLowerCase();
            const faqElements = document.querySelectorAll('[class*="faq"], [class*="question"], [class*="accordion"]');
            
            if (faqElements.length > 0) return { status: 'present', confidence: 0.9 };
            if (pageText.includes('frequently asked') || pageText.includes('faq')) {
                return { status: 'present', confidence: 0.85 };
            }
            return { status: 'missing', confidence: 0.8 };
        }
    },
    
    sizingChart: {
        name: 'Sizing/Measurement Charts',
        category: 'Information Architecture',
        weight: 6,
        check: () => {
            const pageText = document.body.textContent.toLowerCase();
            const tables = document.querySelectorAll('table');
            
            if (tables.length > 0 && (pageText.includes('size') || pageText.includes('measurement'))) {
                return { status: 'present', confidence: 0.85 };
            }
            if (pageText.includes('size chart') || pageText.includes('sizing guide')) {
                return { status: 'present', confidence: 0.9 };
            }
            if (pageText.includes('size') || pageText.includes('measurement')) {
                return { status: 'partial', confidence: 0.65 };
            }
            return { status: 'missing', confidence: 0.8 };
        }
    },
    
    shippingInfo: {
        name: 'Shipping Information & Cost',
        category: 'Information Architecture',
        weight: 8,
        check: () => {
            const pageText = document.body.textContent.toLowerCase();
            const shippingKeywords = ['shipping', 'delivery', 'free shipping', 'estimated'];
            const found = shippingKeywords.filter(kw => pageText.includes(kw)).length;
            
            if (found >= 2) return { status: 'present', confidence: 0.85 };
            if (found >= 1) return { status: 'partial', confidence: 0.7 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    shippingDate: {
        name: 'Expected Shipping Date',
        category: 'Information Architecture',
        weight: 6,
        check: () => {
            const pageText = document.body.textContent.toLowerCase();
            if (pageText.match(/ship|deliver|arrive|date|days?|week/i)) {
                return { status: 'present', confidence: 0.75 };
            }
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    recommendations: {
        name: 'Product Recommendations',
        category: 'Recommendations & Engagement',
        weight: 7,
        check: () => {
            const recommendations = document.querySelectorAll('[class*="recommend"], [class*="related"], [class*="similar"]');
            if (recommendations.length > 0) return { status: 'present', confidence: 0.9 };
            return { status: 'missing', confidence: 0.8 };
        }
    },
    
    upsellProducts: {
        name: 'Upsell Products (Higher-Priced)',
        category: 'Recommendations & Engagement',
        weight: 6,
        check: () => {
            const recommendations = document.querySelectorAll('[class*="recommend"], [class*="related"], [class*="similar"]');
            if (recommendations.length > 0) return { status: 'partial', confidence: 0.7 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    crosssellProducts: {
        name: 'Cross-sell Products (Supplementary)',
        category: 'Recommendations & Engagement',
        weight: 6,
        check: () => {
            const recommendations = document.querySelectorAll('[class*="recommend"], [class*="related"], [class*="similar"]');
            if (recommendations.length > 0) return { status: 'partial', confidence: 0.7 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    liveChat: {
        name: 'Live Chat Option',
        category: 'Recommendations & Engagement',
        weight: 5,
        check: () => {
            const chatElements = document.querySelectorAll('[class*="chat"], [class*="support"], [class*="help"]');
            if (chatElements.length > 0) return { status: 'present', confidence: 0.8 };
            return { status: 'missing', confidence: 0.85 };
        }
    },
    
    pageSpeed: {
        name: 'Page Load Speed (<3 seconds)',
        category: 'Performance',
        weight: 8,
        check: () => {
            if (window.performance && window.performance.timing) {
                const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;
                const seconds = loadTime / 1000;
                
                if (seconds < 3) return { status: 'present', confidence: 0.9 };
                if (seconds < 5) return { status: 'partial', confidence: 0.7 };
                return { status: 'missing', confidence: 0.8 };
            }
            return { status: 'unknown', confidence: 0.5 };
        }
    }
};

// Analyze the page
function analyzePage() {
    const results = {};
    let totalWeight = 0;
    let totalScore = 0;

    for (const [key, criterion] of Object.entries(CONVERSION_CRITERIA)) {
        try {
            const result = criterion.check();
            results[key] = {
                name: criterion.name,
                category: criterion.category,
                weight: criterion.weight,
                status: result.status,
                confidence: result.confidence
            };

            // Calculate weighted score
            let statusScore = 0;
            if (result.status === 'present') statusScore = 1;
            else if (result.status === 'partial') statusScore = 0.5;
            else if (result.status === 'missing') statusScore = 0;
            else statusScore = 0.25; // unknown

            totalScore += statusScore * criterion.weight * result.confidence;
            totalWeight += criterion.weight * result.confidence;
        } catch (err) {
            results[key] = {
                name: criterion.name,
                category: criterion.category,
                weight: criterion.weight,
                status: 'error',
                error: err.message
            };
        }
    }

    const overallScore = totalWeight > 0 ? Math.round((totalScore / totalWeight) * 100) : 0;

    return {
        url: window.location.href,
        title: document.title,
        timestamp: new Date().toISOString(),
        overallScore: overallScore,
        results: results,
        recommendations: generateRecommendations(results)
    };
}

// Generate recommendations based on analysis
function generateRecommendations(results) {
    const recommendations = [];
    const categories = {};

    // Group by category and status
    for (const [key, result] of Object.entries(results)) {
        if (result.status === 'missing' || result.status === 'partial') {
            if (!categories[result.category]) {
                categories[result.category] = [];
            }
            categories[result.category].push(result);
        }
    }

    // Generate recommendations
    for (const [category, items] of Object.entries(categories)) {
        items.forEach(item => {
            let recommendation = '';
            
            switch (item.name) {
                case 'Featured Image Quality':
                    recommendation = 'Use high-resolution product images (at least 500x500px) that load quickly on mobile devices.';
                    break;
                case 'Image Gallery (Multiple Angles)':
                    recommendation = 'Add a gallery with at least 3-5 images showing the product from different angles and close-ups.';
                    break;
                case 'Descriptive Product Title':
                    recommendation = 'Create a descriptive title (30-200 characters) that includes key product features and keywords.';
                    break;
                case 'Product Ratings (First Fold)':
                    recommendation = 'Display star ratings and review counts prominently above the fold to build trust immediately.';
                    break;
                case 'Customer Reviews & Testimonials':
                    recommendation = 'Add at least 3-5 verified customer reviews with photos to increase social proof and conversion.';
                    break;
                case 'Return Policy Highlighted':
                    recommendation = 'Make the return policy clearly visible and easy to find to reduce purchase hesitation.';
                    break;
                case 'Multiple Payment Options':
                    recommendation = 'Display at least 3 payment methods (credit card, PayPal, Apple Pay, etc.) to reduce checkout friction.';
                    break;
                case 'Prominent CTA Button':
                    recommendation = 'Make the "Add to Cart" or "Buy Now" button stand out with contrasting colors and larger font size.';
                    break;
                case 'Clear Price Display with Anchoring':
                    recommendation = 'Show the original price crossed out next to the current price to highlight savings and value.';
                    break;
                case 'Incentives & Savings Display':
                    recommendation = 'Display discounts, free gifts, or limited-time offers prominently to encourage immediate purchase.';
                    break;
                case 'Breadcrumb Navigation':
                    recommendation = 'Add breadcrumb navigation to help users understand site structure and improve navigation.';
                    break;
                case 'FAQ Section Access':
                    recommendation = 'Create or link to an FAQ section addressing common product questions and concerns.';
                    break;
                case 'Sizing/Measurement Charts':
                    recommendation = 'Include detailed sizing charts with multiple measurement systems (US, UK, EU) to reduce returns.';
                    break;
                case 'Shipping Information & Cost':
                    recommendation = 'Display shipping costs and delivery estimates upfront to prevent cart abandonment.';
                    break;
                case 'Expected Shipping Date':
                    recommendation = 'Show the expected delivery date clearly so customers know when to expect their purchase.';
                    break;
                case 'Product Recommendations':
                    recommendation = 'Add related or similar product recommendations to increase average order value.';
                    break;
                case 'Upsell Products (Higher-Priced)':
                    recommendation = 'Include higher-priced product alternatives to encourage customers to upgrade their purchase.';
                    break;
                case 'Cross-sell Products (Supplementary)':
                    recommendation = 'Suggest complementary products that pair well with the main product.';
                    break;
                case 'Live Chat Option':
                    recommendation = 'Add a live chat feature to provide instant customer support and reduce cart abandonment.';
                    break;
                case 'Page Load Speed (<3 seconds)':
                    recommendation = 'Optimize images, reduce server response time, and minimize CSS/JS to improve page load speed.';
                    break;
                default:
                    recommendation = `Improve: ${item.name}`;
            }

            recommendations.push({
                element: item.name,
                category: category,
                priority: item.status === 'missing' ? 'High' : 'Medium',
                recommendation: recommendation
            });
        });
    }

    // Sort by priority
    recommendations.sort((a, b) => {
        const priorityOrder = { 'High': 0, 'Medium': 1, 'Low': 2 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

    return recommendations;
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'analyze') {
        try {
            const analysis = analyzePage();
            
            // Send analysis back to popup
            chrome.runtime.sendMessage({
                action: 'analysisComplete',
                data: analysis
            });
            
            sendResponse({ success: true });
        } catch (err) {
            chrome.runtime.sendMessage({
                action: 'analysisError',
                error: err.message
            });
            sendResponse({ success: false, error: err.message });
        }
    }
});
