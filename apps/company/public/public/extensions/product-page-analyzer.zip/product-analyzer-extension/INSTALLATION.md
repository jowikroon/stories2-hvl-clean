# Installation Guide - Product Page Analyzer

## Quick Start (Developer Mode)

### Step 1: Download the Extension
- The extension files are located in this folder
- All necessary files are included

### Step 2: Open Chrome Extensions Page
1. Open Google Chrome
2. Click the menu button (⋮) in the top-right corner
3. Select **More tools** → **Extensions**
4. Or paste this in your address bar: `chrome://extensions/`

### Step 3: Enable Developer Mode
1. Look for the **Developer mode** toggle in the top-right corner
2. Click it to turn it ON (it will turn blue)

### Step 4: Load the Extension
1. Click the **"Load unpacked"** button
2. Navigate to the folder containing the extension files
3. Select the `product-analyzer-extension` folder
4. Click **"Select Folder"**

### Step 5: Verify Installation
1. The extension should now appear in your extensions list
2. Look for "Product Page Analyzer" with a purple icon
3. You should also see it in your Chrome toolbar (top-right corner)

## Using the Extension

### Analyzing a Product Page

1. **Navigate to a product page** (any e-commerce site)
   - Amazon product pages
   - Shopify stores
   - WooCommerce sites
   - Any product listing

2. **Click the extension icon** in your Chrome toolbar
   - Purple icon with checkmark

3. **Click "Analyze Product Page"**
   - The extension will scan the page

4. **Wait for analysis** (usually 2-5 seconds)
   - You'll see a loading spinner

5. **Click "View Full Report"**
   - Opens a new tab with detailed results

### Understanding Your Report

**Overall Score (0-100)**
- Shows how well the product page is optimized for conversions
- Based on 20 key conversion optimization criteria

**Category Breakdown**
- Visual breakdown of performance by category
- Shows which areas need improvement

**Detailed Analysis**
- Lists all analyzed elements
- Shows status: ✓ Present, ◐ Partial, ✗ Missing
- Filter by status to focus on specific areas

**Recommendations**
- Prioritized list of improvements
- Specific, actionable advice for each recommendation
- Organized by priority (High, Medium, Low)

## Troubleshooting

### Extension Icon Not Showing
**Problem**: Can't see the extension icon in the toolbar
**Solution**: 
1. Go to `chrome://extensions`
2. Find "Product Page Analyzer"
3. Click the pin icon to pin it to the toolbar

### "Analyze" Button Not Working
**Problem**: Clicking analyze doesn't do anything
**Solution**:
1. Make sure you're on a product page
2. Refresh the page (Ctrl+R or Cmd+R)
3. Try analyzing again
4. Check that JavaScript is enabled

### Report Not Loading
**Problem**: Report page shows blank or "No Analysis Found"
**Solution**:
1. Go back and analyze the product page again
2. Make sure you click "View Full Report" immediately after analysis
3. Clear browser cache: Settings → Privacy → Clear browsing data

### Getting "Error" Message
**Problem**: See an error when trying to analyze
**Solution**:
1. The page might have unusual structure
2. Try a different product page
3. Check browser console for details (F12 → Console)

## Advanced Usage

### Analyzing Multiple Pages
1. Analyze one product page
2. View the report
3. Go back to the previous page
4. Analyze a different product page
5. The new report will replace the previous one

### Exporting Results
1. View the report
2. Click **"📥 Download Report"** button
3. A text file will be downloaded with all results
4. Share this file with your team

### Sharing Results
1. View the report
2. Click **"📤 Share Results"** button
3. Choose how to share (copy to clipboard, etc.)

## System Requirements

- **Browser**: Google Chrome 90+ (or Edge, Brave, etc.)
- **OS**: Windows, macOS, or Linux
- **RAM**: Minimal (< 50MB)
- **Internet**: Not required for analysis (works offline)

## Permissions Explained

The extension requests these permissions:

| Permission | Why | Data Shared |
|-----------|-----|-------------|
| activeTab | To analyze current page | None |
| scripting | To scan page content | None |
| storage | To save analysis results | None |
| host_permissions | To work on any website | None |

**Privacy**: All analysis happens on your device. No data is sent to external servers.

## Updating the Extension

### Manual Updates
1. Download the latest version
2. Go to `chrome://extensions`
3. Click the trash icon to remove old version
4. Load the new version following steps above

### Auto-Updates (When Published)
Once the extension is published to Chrome Web Store, it will auto-update automatically.

## Uninstalling

1. Go to `chrome://extensions`
2. Find "Product Page Analyzer"
3. Click the trash/remove icon
4. Confirm removal

## Tips for Best Results

### 1. Analyze Real Product Pages
- Works best on actual e-commerce product pages
- Test on different platforms (Amazon, Shopify, etc.)

### 2. Review Confidence Scores
- Higher confidence = more reliable analysis
- Low confidence scores may need manual review

### 3. Focus on High Priority Items
- Start with "High Priority" recommendations
- These have the biggest impact on conversions

### 4. Test Improvements
- Make recommended changes
- Re-analyze to see score improvement
- Track progress over time

### 5. Use with Team
- Download reports
- Share with marketing/product teams
- Discuss recommendations together

## Common Questions

**Q: Does this work on mobile?**
A: No, this is a Chrome desktop extension only. Mobile support coming soon.

**Q: Can I analyze pages I don't own?**
A: Yes, you can analyze any product page. Use insights to improve your own pages.

**Q: Is my data private?**
A: Yes, all analysis is local. No data is sent anywhere.

**Q: How often should I analyze?**
A: Analyze after making changes to see improvement. Monthly reviews recommended.

**Q: Can I customize the scoring?**
A: Not yet, but custom weights are coming in future versions.

**Q: Does it work on mobile sites?**
A: Yes, it analyzes mobile versions too.

## Getting Help

1. **Check this guide** - Most issues are covered
2. **Review the README** - Full feature documentation
3. **Check browser console** - F12 → Console for error messages
4. **Try a different page** - Some sites may have unusual structure

## Feedback & Suggestions

We'd love to hear from you!
- Found a bug? Let us know
- Have a suggestion? We're listening
- Want a feature? Tell us what you need

---

**Happy analyzing!** 🚀

For more information, see README.md
