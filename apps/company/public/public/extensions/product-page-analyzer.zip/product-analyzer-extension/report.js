// Report Display Script

document.addEventListener('DOMContentLoaded', async () => {
    // Get analysis data from storage
    const data = await chrome.storage.local.get(['lastAnalysis']);
    
    if (!data.lastAnalysis) {
        document.body.innerHTML = '<div style="padding: 40px; text-align: center;"><h1>No Analysis Found</h1><p>Please analyze a product page first.</p></div>';
        return;
    }

    const analysis = data.lastAnalysis;
    populateReport(analysis);
    setupEventListeners();
});

function populateReport(analysis) {
    // Populate header info
    document.getElementById('scoreValue').textContent = analysis.overallScore;
    document.getElementById('pageUrl').textContent = analysis.url;
    document.getElementById('pageTitle').textContent = analysis.title;
    
    const date = new Date(analysis.timestamp);
    document.getElementById('analyzeTime').textContent = date.toLocaleString();

    // Populate category breakdown
    const categoryScores = calculateCategoryScores(analysis.results);
    populateCategories(categoryScores);

    // Populate detailed results
    populateResults(analysis.results);

    // Populate recommendations
    populateRecommendations(analysis.recommendations);
}

function calculateCategoryScores(results) {
    const categories = {};

    for (const [key, result] of Object.entries(results)) {
        if (!categories[result.category]) {
            categories[result.category] = {
                total: 0,
                weight: 0,
                items: []
            };
        }

        let statusScore = 0;
        if (result.status === 'present') statusScore = 1;
        else if (result.status === 'partial') statusScore = 0.5;
        else if (result.status === 'missing') statusScore = 0;
        else statusScore = 0.25;

        categories[result.category].total += statusScore * result.weight;
        categories[result.category].weight += result.weight;
        categories[result.category].items.push(result);
    }

    // Calculate percentages
    for (const category in categories) {
        const score = categories[category].weight > 0 
            ? Math.round((categories[category].total / categories[category].weight) * 100)
            : 0;
        categories[category].score = score;
    }

    return categories;
}

function populateCategories(categoryScores) {
    const grid = document.getElementById('categoriesGrid');
    grid.innerHTML = '';

    for (const [category, data] of Object.entries(categoryScores)) {
        const card = document.createElement('div');
        card.className = 'category-card';
        card.innerHTML = `
            <div class="category-name">${category}</div>
            <div class="category-score">${data.score}%</div>
        `;
        grid.appendChild(card);
    }
}

function populateResults(results) {
    const list = document.getElementById('resultsList');
    list.innerHTML = '';

    // Create result items
    const resultItems = [];
    for (const [key, result] of Object.entries(results)) {
        const item = document.createElement('div');
        item.className = `result-item ${result.status}`;
        item.dataset.status = result.status;

        let icon = '❓';
        if (result.status === 'present') icon = '✓';
        else if (result.status === 'partial') icon = '◐';
        else if (result.status === 'missing') icon = '✗';

        let statusText = result.status.charAt(0).toUpperCase() + result.status.slice(1);

        item.innerHTML = `
            <div class="result-icon">${icon}</div>
            <div class="result-content">
                <div class="result-name">${result.name}</div>
                <div class="result-category">${result.category}</div>
                <span class="result-status ${result.status}">${statusText}</span>
            </div>
        `;

        resultItems.push({ item, status: result.status });
        list.appendChild(item);
    }

    // Store for filtering
    window.resultItems = resultItems;
}

function populateRecommendations(recommendations) {
    const list = document.getElementById('recommendationsList');
    list.innerHTML = '';

    if (recommendations.length === 0) {
        list.innerHTML = '<p style="text-align: center; color: var(--text-secondary); padding: 20px;">Great! No immediate recommendations. Your product page is well-optimized.</p>';
        return;
    }

    recommendations.forEach(rec => {
        const item = document.createElement('div');
        item.className = 'recommendation-item';
        
        const priorityClass = rec.priority.toLowerCase();
        
        item.innerHTML = `
            <div style="flex: 1;">
                <span class="recommendation-priority ${priorityClass}">${rec.priority} Priority</span>
                <div class="recommendation-element">${rec.element}</div>
                <div class="recommendation-text">${rec.recommendation}</div>
                <div class="recommendation-category">Category: ${rec.category}</div>
            </div>
        `;
        
        list.appendChild(item);
    });
}

function setupEventListeners() {
    // Tab filtering
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active tab
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Filter results
            const filter = btn.dataset.tab;
            filterResults(filter);
        });
    });

    // Download button
    document.getElementById('downloadBtn').addEventListener('click', downloadReport);

    // Share button
    document.getElementById('shareBtn').addEventListener('click', shareReport);
}

function filterResults(filter) {
    const items = window.resultItems || [];
    
    items.forEach(({ item, status }) => {
        if (filter === 'all') {
            item.classList.remove('hidden');
        } else if (filter === status) {
            item.classList.remove('hidden');
        } else {
            item.classList.add('hidden');
        }
    });
}

function downloadReport() {
    const analysis = window.analysisData;
    const content = generateReportText();
    
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', `product-analysis-${Date.now()}.txt`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

function generateReportText() {
    const data = document.getElementById('scoreValue').textContent;
    const url = document.getElementById('pageUrl').textContent;
    const title = document.getElementById('pageTitle').textContent;
    const time = document.getElementById('analyzeTime').textContent;

    let text = `PRODUCT PAGE ANALYSIS REPORT\n`;
    text += `${'='.repeat(50)}\n\n`;
    text += `Overall Score: ${data}/100\n`;
    text += `URL: ${url}\n`;
    text += `Title: ${title}\n`;
    text += `Analyzed: ${time}\n\n`;

    const items = document.querySelectorAll('.result-item');
    text += `DETAILED ANALYSIS\n`;
    text += `${'-'.repeat(50)}\n\n`;

    items.forEach(item => {
        const name = item.querySelector('.result-name').textContent;
        const status = item.querySelector('.result-status').textContent;
        text += `${name}: ${status}\n`;
    });

    const recommendations = document.querySelectorAll('.recommendation-item');
    if (recommendations.length > 0) {
        text += `\nRECOMMENDATIONS\n`;
        text += `${'-'.repeat(50)}\n\n`;

        recommendations.forEach((rec, idx) => {
            const element = rec.querySelector('.recommendation-element').textContent;
            const recommendation = rec.querySelector('.recommendation-text').textContent;
            const priority = rec.querySelector('.recommendation-priority').textContent;
            
            text += `${idx + 1}. ${element} (${priority})\n`;
            text += `   ${recommendation}\n\n`;
        });
    }

    return text;
}

function shareReport() {
    const url = document.getElementById('pageUrl').textContent;
    const score = document.getElementById('scoreValue').textContent;
    
    const text = `I just analyzed a product page and got a conversion optimization score of ${score}/100. Check out the Product Page Analyzer extension!`;
    
    // Try to use Web Share API
    if (navigator.share) {
        navigator.share({
            title: 'Product Page Analysis',
            text: text,
            url: url
        }).catch(err => console.log('Error sharing:', err));
    } else {
        // Fallback: copy to clipboard
        const shareText = `${text}\n${url}`;
        navigator.clipboard.writeText(shareText).then(() => {
            alert('Report copied to clipboard!');
        }).catch(err => {
            alert('Could not copy to clipboard');
        });
    }
}

// Store analysis data for later use
chrome.storage.local.get(['lastAnalysis'], (data) => {
    if (data.lastAnalysis) {
        window.analysisData = data.lastAnalysis;
    }
});


/**
 * Comparison Mode Functions
 */
function initializeComparisonMode() {
    const urlParams = new URLSearchParams(window.location.search);
    const mode = urlParams.get('mode');

    if (mode === 'compare') {
        chrome.storage.local.get(['analysisHistory'], (result) => {
            if (result.analysisHistory && result.analysisHistory.length >= 2) {
                displayComparisonMode(result.analysisHistory);
            }
        });
    }
}

function displayComparisonMode(history) {
    const comparisonSection = document.getElementById('comparisonSection');
    const comparisonContainer = document.getElementById('comparisonContainer');
    
    comparisonSection.style.display = 'block';
    
    // Get top 2 analyses
    const analysis1 = history[0];
    const analysis2 = history[1];
    
    // Create comparison cards
    let html = '<div class="comparison-cards">';
    
    // Card 1
    html += `
        <div class="comparison-card">
            <div class="comparison-header">
                <h3>${analysis1.title || 'Current Page'}</h3>
                <div class="comparison-score">${Math.round(analysis1.score)}</div>
            </div>
            <div class="comparison-details">
                <p class="comparison-url">${new URL(analysis1.url).hostname}</p>
                <p class="comparison-time">${new Date(analysis1.timestamp).toLocaleDateString()}</p>
            </div>
            <div class="comparison-stats">
                <div class="stat">
                    <span class="stat-label">Present</span>
                    <span class="stat-value">${analysis1.results.filter(r => r.status === 'present').length}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Partial</span>
                    <span class="stat-value">${analysis1.results.filter(r => r.status === 'partial').length}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Missing</span>
                    <span class="stat-value">${analysis1.results.filter(r => r.status === 'missing').length}</span>
                </div>
            </div>
        </div>
    `;
    
    // Comparison Arrow
    html += '<div class="comparison-arrow">⚖️</div>';
    
    // Card 2
    html += `
        <div class="comparison-card">
            <div class="comparison-header">
                <h3>${analysis2.title || 'Previous Page'}</h3>
                <div class="comparison-score">${Math.round(analysis2.score)}</div>
            </div>
            <div class="comparison-details">
                <p class="comparison-url">${new URL(analysis2.url).hostname}</p>
                <p class="comparison-time">${new Date(analysis2.timestamp).toLocaleDateString()}</p>
            </div>
            <div class="comparison-stats">
                <div class="stat">
                    <span class="stat-label">Present</span>
                    <span class="stat-value">${analysis2.results.filter(r => r.status === 'present').length}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Partial</span>
                    <span class="stat-value">${analysis2.results.filter(r => r.status === 'partial').length}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Missing</span>
                    <span class="stat-value">${analysis2.results.filter(r => r.status === 'missing').length}</span>
                </div>
            </div>
        </div>
    `;
    
    html += '</div>';
    
    // Difference Analysis
    const scoreDiff = Math.round(analysis1.score) - Math.round(analysis2.score);
    const scoreDiffPercent = scoreDiff > 0 ? '+' : '';
    const scoreDiffColor = scoreDiff > 0 ? '#10b981' : scoreDiff < 0 ? '#ef4444' : '#6b7280';
    
    html += `
        <div class="comparison-analysis">
            <h4>Score Difference</h4>
            <div class="score-diff" style="color: ${scoreDiffColor}">
                ${scoreDiffPercent}${scoreDiff} points
            </div>
            <p class="diff-description">
                ${scoreDiff > 0 ? 'Current page is performing better' : scoreDiff < 0 ? 'Previous page was performing better' : 'Both pages have similar scores'}
            </p>
        </div>
    `;
    
    comparisonContainer.innerHTML = html;
}

// Initialize comparison mode on page load
document.addEventListener('DOMContentLoaded', () => {
    initializeComparisonMode();
});
